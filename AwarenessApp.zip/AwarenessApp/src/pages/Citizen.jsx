import React from "react";

export default function Citizen() {
  return (
    <div className="page">
      <h2>Citizen Section</h2>
      <p>
        Explore articles, learn your rights and duties, and join discussions.
      </p>
    </div>
  );
}
