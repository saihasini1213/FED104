import React from "react";

export default function Admin() {
  return (
    <div className="page">
      <h2>Admin Dashboard</h2>
      <p>Manage users, verify information, and oversee educational content.</p>
    </div>
  );
}
