import React from "react";

export default function Educator() {
  return (
    <div className="page">
      <h2>Educator Panel</h2>
      <p>
        Create learning materials, organize quizzes, and conduct awareness sessions.
      </p>
    </div>
  );
}
